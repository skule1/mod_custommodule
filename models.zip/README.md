## Bestillingshistorikk på eShop
Listen over tidligere bestillinger kommer opp under Min Side for brukere som er logget på.
